app.config(function($stateProvider, $urlRouterProvider) {
	debugger;
    $urlRouterProvider.otherwise('/dashboard');
    $stateProvider
        .state('dashboard', {
            url: '/dashboard',
            templateUrl: 'resources/pages/dashboard.jsp',
            controller : 'dashboardCtrl'
        })
        .state('restartinfo', {
            url: '/restartinfo',
            templateUrl: 'resources/pages/restartinfo.jsp',
            controller : 'restartinfoCtrl'
        })
        .state('presistData', {
            url: '/presistData',
            templateUrl: 'resources/pages/presistData.jsp',
            controller : 'presistDataCtrl'
        })
        .state('preTest', {
            url: '/preTest',
            templateUrl: 'resources/pages/preTest.jsp',
            controller : 'preTestCtrl'
        })
        .state('versionComp', {
            url: '/versionComp',
            templateUrl: 'resources/pages/versionComp.jsp',
            controller : 'versionCompCtrl'
        });

});