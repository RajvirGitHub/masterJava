function clearit(){
  var x={};
  updateGraph(x);
}