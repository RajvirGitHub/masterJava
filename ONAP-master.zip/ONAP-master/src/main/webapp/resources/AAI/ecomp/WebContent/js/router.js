app.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/dashboard');
    $stateProvider
        .state('dashboard', {
            url: '/dashboard',
            templateUrl: './pages/dashboard.html',
            controller : 'dashboardCtrl'
        })
        .state('version', {
            url: '/version',
            templateUrl: './pages/version.html',
            controller : 'versionCtrl'
        })
        .state('restartinfo', {
            url: '/restartinfo',
            templateUrl: './pages/restartinfo.html',
            controller : 'restartinfoCtrl'
        });

});