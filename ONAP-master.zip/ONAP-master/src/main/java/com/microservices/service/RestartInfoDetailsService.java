package com.microservices.service;

import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.RestartInfoDetailsRestModel;

public interface RestartInfoDetailsService {

	JsonResponse<RestartInfoDetailsRestModel> addRestartInfoDetails(RestartInfoDetailsRestModel router);

}
