package com.microservices.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.dao.RestartInfoDetailsDao;
import com.microservices.dao.model.RestartInfoDetails;
import com.microservices.repositories.RestartInfoDetailsRepository;
import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.RestartInfoDetailsRestModel;

@Service
public class RestartInfoDetailsServiceImpl implements RestartInfoDetailsService {

	
	@Autowired
	private RestartInfoDetailsRepository restartInfoDetailsRepo;
	
	@Autowired
	private RestartInfoDetailsDao seqDao;
	
		@Override
		public JsonResponse<RestartInfoDetailsRestModel> addRestartInfoDetails(RestartInfoDetailsRestModel obj) {
			JsonResponse<RestartInfoDetailsRestModel> response = new JsonResponse<RestartInfoDetailsRestModel>();
			response.setResponseBody(null);

			try{
				RestartInfoDetails temp=new RestartInfoDetails();
				temp.setLink1(obj.getLink1());
				temp.setLink2(obj.getLink2());
				temp.setLink3(obj.getLink3());

				temp.setResult(obj.getResult());
				temp.setTemperature(obj.getTemperature());

				restartInfoDetailsRepo.save(temp);

				System.out.println("record saved Successfully"+obj.getResult());
				response.setStatus(Boolean.TRUE);
				response.setResponseDetail("Restart Information added successfully.");
				response.setResponseBody(obj);
				response.setErrorCode("200");
				System.out.println("Restart Information Details record saved Successfully");
			}
			catch (Exception e)
			{
				e.printStackTrace();
				response.setStatus(Boolean.FALSE);
				response.setResponseDetail("Restart Information addition failed.");
			}

			return response;
}
}
