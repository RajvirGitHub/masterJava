package com.microservices;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.microservices.service.RestartInfoDetailsService;
import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.RestartInfoDetailsRestModel;

@Controller
public class WelcomeController {

	@Autowired
	private RestartInfoDetailsService restartInfoDetailsService;

	@RequestMapping(value = "/")
	public String gotoHomePage1() {
		return "index";
	}

	@RequestMapping(value = "/restartInfo", method = org.springframework.web.bind.annotation.RequestMethod.POST,produces = {
	"application/json" }, consumes = { "application/json" })
	public JsonResponse<RestartInfoDetailsRestModel> saveRestartInfoDetails(@RequestBody RestartInfoDetailsRestModel obj, HttpSession session/*,
			Model model*/) {
		
		JsonResponse<RestartInfoDetailsRestModel> response = new JsonResponse<RestartInfoDetailsRestModel>();
		response.setResponseBody(null);
		
		System.out.println("router : " + obj);
		
		response = restartInfoDetailsService.addRestartInfoDetails(obj);
		session.setAttribute("getAlert", "yes");

		/*model.addAttribute("command", new RestartInfoDetailsRestModel());*/
		return response;
	}

	/*@RequestMapping(value="/saveEmp",method=org.springframework.web.bind.annotation.RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("command") EmployeeRestModel employee,HttpSession session,Model model)
	{	
		System.out.println("emp : "+employee);
			
		List<String> empDetails=new ArrayList<>();
		
		empDetails.add(employee.getFname());
		empDetails.add(employee.getLname());
		empDetails.add(employee.getDept());
		empDetails.add(employee.getCity());
		
		String msg=empService.saveEmp(empDetails);
		session.setAttribute("getAlert", "yes");
		
		model.addAttribute("command", new EmployeeRestModel());
		return "addEmployee";
	}*/
}
