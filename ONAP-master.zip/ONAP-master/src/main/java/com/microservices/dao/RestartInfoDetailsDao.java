package com.microservices.dao;


public interface RestartInfoDetailsDao {

	
}
